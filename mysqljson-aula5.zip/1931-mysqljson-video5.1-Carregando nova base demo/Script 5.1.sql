SELECT * FROM tb_object_funcionario;
SELECT JSON_PRETTY(JSON) FROM tb_object_funcionario;
