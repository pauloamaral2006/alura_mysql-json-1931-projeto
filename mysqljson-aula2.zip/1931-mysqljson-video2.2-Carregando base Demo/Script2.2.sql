
SELECT * FROM countryinfo ;
SELECT DOC FROM countryinfo WHERE _id = 'USA';